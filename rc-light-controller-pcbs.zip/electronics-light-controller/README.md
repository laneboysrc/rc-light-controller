This folder contains the [KiCAD](http://kicad-pcb.org/) files for the MK4 TLC5940 LPC812 variant, revision 2

Schematics are provided as PNG [schematics.png](schematics.png) and PDF [schematics.pdf](schematics.pdf)