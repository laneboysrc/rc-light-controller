# Locations of the pads for the LEDs

Measurements in mm; 0/0 is the pad OUT11 on the lower-left corner of the light controller.

    Pad         X       Y

    OUT11       0       0
    OUT12       2.8     0
    OUT13       4.8     0
    OUT14       6.9     0
    OUT15       8.9     0
    OUT15S      10.9    0
    +LED1       14.7    0
    +LED2       16.8    0

    OUT10       0       2
    OUT9        0       4.1
    OUT8        0       6.1
    OUT7        0       8.4
    OUT6        0       10.4
    OUT5        0       12.4
    OUT4        0       14.4

    OUT3        2.8     14.4
    OUT2        4.8     14.4
    OUT1        6.9     14.4
    OUT0        8.9     14.4