intel-hex.js
============

A parser/writer for Intel HEX file format.
