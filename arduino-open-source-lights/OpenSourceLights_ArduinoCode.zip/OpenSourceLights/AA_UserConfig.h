// This file lists the variables configurable by the user

    #define NumSchemes  4                  // The number of lighting schemes allowed. Theoretically it can be anything up the memory limit. In practice, 4 is probably plenty


// TWEAKS FOR YOUR LIGHTS
// ------------------------------------------------------------------------------------------------------------------------------------------------>
    #define DimLevel                    20          // Number from 0-255, with 0 being off, 255 being full on. Often numbers much greater than half (128) are hard to distinguish from full on. 
                                                    // Experiment to get the number that makes your lights as dim as you want them. 
    
    #define BlinkInterval              500          // A value in milliseconds that sets the blink rate for blinking lights set to "Blink" (for example, turn signals). 1000 = 1 second
    #define FastBlinkInterval           20          // A value in milliseconds that sets the fast blink rate for lights set to "FastBlink"


// DOUBLE TAP REVERSE
// -------------------------------------------------------------------------------------------------------------------------------------------->
    #define DoubleTapReverse          true          // Most ESCs require you to tap reverse twice before the car actually goes into reverse. 
                                                    // If yours is like this, set it to true, otherwise put it to false. 
                                                    
// COASTING
// -------------------------------------------------------------------------------------------------------------------------------------------->
    // If we didn't allow any time for the car to coast to a stop, there would be no need for braking, and your brake lights would never come on. However in real life, 
    // your car does coast even after you let off the 'gas'. During this time, opposite throttle commands are actually counted as a command to change direction, but instead
    // are counted as braking. Tweak the coast times here to match what you see in real life. They are in milliseconds. 
    // 1000 ms = 1 second
    #define TimeToStop_FWD_mS          700          // An estimate of the time usually spent coasting to a stop from forward. During this time, reverse commands will be counted as braking
    #define TimeToStop_REV_mS          400          // An estimate of the time usually spent coasting to a stop fro reverse. During this time, forward commands will be counted as braking


// SHIFTING TIME
// -------------------------------------------------------------------------------------------------------------------------------------------->
    // How much of a pause is required before changing directions (from forward to reverse or from reverse to forward). 
    // For most ESCs this will be close to zero. 
    #define TimeToShift_mS             300          // The pause time in milliseconds that will be required before the vehicle is allowed to change direction


// DEADBAND
// -------------------------------------------------------------------------------------------------------------------------------------------->
    // This reduces the sensitivity around center stick. The numbers can be 0-100 but should be rather small, like 10. This prevents minor movements of your sticks when
    // stopped from  setting off your lights. 
    // Note: if you find you need to set these numbers to high values, what you probably need is to run through Radio Setup instead. 
    #define ThrottleDeadband            10          // Throttle channel hysteriesis. Values below this will be ignored. Default is 10, number should be small. 
    #define TurnDeadband                15          // Same thing, but for steering channel. 


// DEBUGGING
// ------------------------------------------------------------------------------------------------------------------------------------------------>
    #define DEBUG                     true          // Set this to true to receive debugging messages out the serial port
    #define LED_DEBUG                 true          // If this is set to true, the Green LED on the board will be on whenever the car is moving forward or reverse, off if stopped. 
                                                    // The Red LED will turn on whenever the car is braking. You can use these to verify the board is reflecting the behavior
                                                    // of your car without needing any lights to be connected.
                                                    
// SERIAL
// ------------------------------------------------------------------------------------------------------------------------------------------------>
    #define BaudRate                 38400          // Set baud rate here if you know what you're doing and don't like the default value

                                                    
                                                    

