Instructions: 

1. Put the folder named "OpenSourceLights" into your Arduino "Sketches" folder. This may be a place you specified or it may be the default location that Arduino chose. If you are unsure where Arduino thinks your Sketches folder is:
- Open the Arduino IDE
- Go to File -> Preferences
- At the top of the popup screen that appears, look at the path under the heading "Sketchbook location". This shows you where your Sketches folder is. 

2. You can put the folder named "libraries" into one of two places: 
- Your Sketches folder
- Program Files\Arduino and overwrite the libraries folder already there (don't worry, it will only add the new information but keep the old libraries intact)
Either location will work fine. 

3. Compile and upload
- Open the Arduino IDE
- Make sure you have the correct board selected. Go to Tools -> Board -> "Arduino Duemilanove w/ Atmega 328"
- Make sure you have the correct com port selected (the one hooked up to your board) - this is in Tools -> Serial Port
- Click the "Upload" button to send the code to the board (this is the icon with the arrow facing right)